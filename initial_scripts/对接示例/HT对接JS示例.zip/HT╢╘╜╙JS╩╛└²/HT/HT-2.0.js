/**
 *
 * 呼叫中心方法对象
 * 2.0
 *
 * 提供方法
 * HT.signIn(username,exten,callbackFn)		//签到
 * HT.signOut(username,callbackFn)			//签退
 *
 */

var HT = {
	path : "http://10.11.5.114:8088/ec2/http/common/",//请求地址
	threadTime : 1000,		//访问请求频率1s
	connectStatus:false,	//连接状态
	showWindowStatus:false,	//是否显示弹窗
	accessId: "2016010872924653HTDM1",
	accessKey: "BB9BC9DBCB699FAD266D11F9D622B4BC"
};

/**
 * 签到
 * (String)username		用户名
 * (String)exten		分机
 * (function)callbackFn	回调函数
 *
 */
HT.signIn = function(username,exten,callbackFn){
	var _self = this;
	if(username && exten){
		jq183.ajax({
			url :  _self.path + "loginBind",	 //地址
			data:{username:username,exten:exten},//参数
			type : "GET", 						 //方式
			cache:false,						 //不缓存
			dataType : "jsonp", 				 //JSONP
			jsonpCallback:"callback",			 //JSONP回调函数名称
	 		timeout: 1000,						 //超时
			success : function(data) {
				if(data["code"] == 0){
					_self._timerStart(username);
				}
				callbackFn(data);
			},
			error:function(){
				callbackFn({code:-2,message:'签到请求错误'});
				_self._timerStart(username);
			}
		});
	}else{
		callbackFn({code:-1,message:'参数错误'});
	}
};

/**
 * 签退
 * (String)username		用户名
 * (function)callbackFn	回调函数
 *
 */
HT.signOut = function(username,callbackFn){
	var _self = this;
	if(username){
		jq183.ajax({
			url :  _self.path + "logoutUnbind",	//地址
			data:{username:username},			//参数
			type : "GET", 						//方式
			cache:false,						//不缓存
			dataType : "jsonp", 				//JSONP
			jsonpCallback:"callback",			//JSONP回调函数名称
	 		timeout: 60000,						//超时
			success : function(data) {
				if(data["code"] == 0){
					_self._timerStop();
				}
				callbackFn(data);
			},
			error:function(){
				callbackFn({code:-2,message:'签退请求错误'});
			}
		});
	}else{
		callbackFn({code:-1,message:'参数错误'});
	}
};

HT.timeInfo = function(username){
	var _self = this;
	_self.connectStatus = true;
	_self.showWindowStatus = true;

	setInterval(function() {

		if(_self.showWindowStatus) {
			jq183.ajax({
				url: _self.path + "timeInfo",		// 地址
				data: {"timedate":(new Date()).getTime(), username:username, accessId:_self.accessId, accessKey:_self.accessKey},	// 参数
				type: "GET",						// 请求方式
				async: false,						// 同步设置
				cache: false,						// 缓存设置
				dataType: "jsonp",					// JSONP
				jsonpCallback: "callbackTimeInfo",	// 回调函数, 这里设为固定, 不要修改
				timeout: 3000,						// 请求超时设置
				success: function(data, textStatus) {
					if(data['resultsPhoneIn']) {
						HT._showPhoneInbound(data['resultsPhoneIn']);
						
					} else if(data['resultsBridge']) {
						HT._showBridgeInfo(data['resultsBridge']);
						
					} else if(data['resultsHangUp']) {
						HT._showHangupInfo(data['resultsHangUp']);
					}
				},
				error: function(jqXHR, textStatus, errorThrown) {
					jqXHR = null;
				}
			});
		}

	}, HT.threadTime);

};


//开始连接
HT._timerStart = function(username){
	var _self = this;
	if(!_self.connectStatus){
		HT.timeInfo(username);
	}
};

//停止不显示弹窗
HT._timerStop = function(){
	var _self = this;
	_self.showWindowStatus = false;
};

//回调弹屏方法
HT._showPhoneInbound= function(data) {
	phoneInbound(data);
};

// 回调接起信息方法
HT._showBridgeInfo = function(data) {
	bridgeInfo(data);
}

// 回调挂断信息方法
HT._showHangupInfo = function(data) {
	hangupInfo(data);
}
